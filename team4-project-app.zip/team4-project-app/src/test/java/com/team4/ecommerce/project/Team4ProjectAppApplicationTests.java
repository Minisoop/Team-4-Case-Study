package com.team4.ecommerce.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team4ProjectAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
