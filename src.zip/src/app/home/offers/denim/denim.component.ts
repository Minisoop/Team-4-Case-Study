import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-denim',
  templateUrl: './denim.component.html',
  styleUrls: ['./denim.component.css']
})
export class DenimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
