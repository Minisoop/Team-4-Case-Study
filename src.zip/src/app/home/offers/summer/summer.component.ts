import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-summer',
  templateUrl: './summer.component.html',
  styleUrls: ['./summer.component.css']
})
export class SummerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
