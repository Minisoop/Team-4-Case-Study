import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-throwback',
  templateUrl: './throwback.component.html',
  styleUrls: ['./throwback.component.css']
})
export class ThrowbackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
