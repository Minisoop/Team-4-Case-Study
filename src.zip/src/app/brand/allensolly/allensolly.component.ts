import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allensolly',
  templateUrl: './allensolly.component.html',
  styleUrls: ['./allensolly.component.css']
})
export class AllensollyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
