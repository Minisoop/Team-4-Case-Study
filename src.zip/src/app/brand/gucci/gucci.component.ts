import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gucci',
  templateUrl: './gucci.component.html',
  styleUrls: ['./gucci.component.css']
})
export class GucciComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
