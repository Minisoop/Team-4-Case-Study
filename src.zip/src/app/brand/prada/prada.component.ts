import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prada',
  templateUrl: './prada.component.html',
  styleUrls: ['./prada.component.css']
})
export class PradaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
