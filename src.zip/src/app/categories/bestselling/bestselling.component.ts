import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bestselling',
  templateUrl: './bestselling.component.html',
  styleUrls: ['./bestselling.component.css']
})
export class BestsellingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
