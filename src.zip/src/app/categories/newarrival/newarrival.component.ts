import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newarrival',
  templateUrl: './newarrival.component.html',
  styleUrls: ['./newarrival.component.css']
})
export class NewarrivalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
