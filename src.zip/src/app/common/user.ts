export class User{
    id:number;
    fname: string;
    lname: string;
    emailId : string;
    contact: number;
    birthDate: Date;
    password: string;
    
    constructor(){}
}