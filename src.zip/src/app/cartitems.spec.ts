import { Cartitems } from './cartitems';

describe('Cartitems', () => {
  it('should create an instance', () => {
    expect(new Cartitems()).toBeTruthy();
  });
});
